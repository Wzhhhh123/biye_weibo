
var lineChart = echarts.init(document.getElementById('lines'), 'white', {renderer: 'canvas'});

$(
function changeCountry(){
    $.ajax({
        type: "GET",
        url: "/changecountry",
        dataType: "json",
        success: function (result) {
            lineChart.setOption(result);
        }
    });
})


