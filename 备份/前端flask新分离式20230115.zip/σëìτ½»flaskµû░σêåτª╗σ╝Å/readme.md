
创建数据库命令

CREATE TABLE `weibohotpot1` (
`id` int(8) NOT NULL AUTO_INCREMENT,
`title` varchar(255) DEFAULT NULL,
`url` text,
`hot` int(8) DEFAULT NULL,
`create_date` date DEFAULT NULL,
`zhong` varchar(255) DEFAULT NULL,
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8