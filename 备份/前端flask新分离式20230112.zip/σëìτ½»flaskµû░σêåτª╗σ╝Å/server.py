import json
from random import randrange
from mysql_util import MysqlUtil
from flask.json import jsonify
from flask import Flask, render_template,url_for
from flask import request
import pandas as pd
import requests
import re
from pyecharts import options as opts
from pyecharts.charts import Line





app = Flask(__name__, static_folder="templates")



# 情感分析
@app.route("/")
def login():
    return render_template("home.html")


 

@app.route('/123')
def index():
    db = MysqlUtil()  # 实例化数据库操作类
    count = 3  # 每页显示数量
    page = request.args.get('page')  # 获取当前页码
    if page is None:  # 默认设置页码为1
        page = 1
    # 分页查询
    # 从article表中筛选5条数据，并根据日期降序排序
    sql = f'SELECT * FROM weibohotpot  ORDER BY create_date DESC LIMIT {(int(page) - 1) * count},{count}'
    articles = db.fetchall(sql)  # 获取多条记录
    # 遍历文章数据
    return render_template('home_1.html', articles=articles, page=int(page))  # 渲染模板

@app.route('/admin')
def hello_admin():
   return 'Hello Admin'

@app.route('/guest/<guest>')
def hello_guest(guest):
   return 'Hello %s as Guest' % guest



if __name__ == "__main__":
    app.run(debug = True,host='0.0.0.0',port=5555)
